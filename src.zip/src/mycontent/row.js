import React, { Component,useEffect,useState } from 'react'
import ReactDOM from 'react-dom';
import { render } from 'react-dom'
import "../css/rows.css"
import Modal from './modal'
import axios from "axios"
export default class Row extends Component {
    
    constructor(){
        super();
        var AxiosInstance = axios.create({
            baseURL: 'http://localhost:6789/',
            timeout:1000,
            headers: {'Access-Control-Allow-Origin': true}
        })

        AxiosInstance.get('http://localhost:6789/ping').then(function (response) {
            console.log(response);
          })
    }

    state = {
        pageID:1,
        modalShow:false,
        itemList:[
            {
                gid:0,
                author:"肖邦",
            },
        ],
    }


    cancelModal = ()=>{
        this.setState({
            modalShow:false,
        })
        console.log(this.state.modalShow)
    }

    render(){
        return(
           <div>
               <ul>
                   {
                    this.state.itemList.map(item =><li className='rows' key={item.gid}>
                        <div className='row1'>{item.gid}</div> 
                        <div className='row2'>{item.author}</div>
                        <button className='editButton' onClick={()=>{
                            
                            var v = this.state.modalShow
                            this.setState({
                                modalShow:!v,
                            })
                            console.log(v)
                        }}>edit</button>
                        </li>)
                   }
                </ul>
                {this.state.modalShow && <Modal cancelHandle={this.cancelModal}/>}
           </div> 
        ) 

    }
}