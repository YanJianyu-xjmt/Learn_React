import axios from "axios"

var AxiosInstance = axios.create({
        baseURL: 'http://localhost:6789/',
        timeout:1000,
        headers: {'Access-Control-Allow-Origin': 'foobar'}
    })