
import { toHaveAttribute } from '@testing-library/jest-dom/dist/matchers';
import React, { Component, createRef } from 'react';
import "../css/modal.css"
class Modal extends Component {
  id = this.props.id
  conCancel = this.props.cancelHandle
  nameref = createRef()
  render() {
    // 通过父组件传递的visile控制显隐
    return <div className='modal'>
      <div>
          <input ref={this.nameref}/>
      </div>
      <div>
          <button onClick={this.conCancel}>
         取消
      </button>
      </div>
      
      <div>
          <button onClick={
              ()=>{
                console.log("MMMM")
                console.log(this.nameref.current.value)
                this.conCancel()
              }
          }>
              确认
      </button>
      </div>
    </div>  
  }
}

export default Modal;