import ReactDOM from 'react-dom';
import React, { useState, createContext, useContext, Component } from "react";

import Big from "./mycontent/big"

class Rrr extends Component{
  state = {
    t:false,
  }
  render(){
    return (
      <div>
        <button onClick={
          ()=>{
            this.setState({
              t:true,
            })
          }
        }>
          ppp
        </button>
        {this.state.t &&<div>1111</div>}
      </div>
    )
  }
}
ReactDOM.render(
  <Big/>,document.getElementById("root")
);

