import React, { Component } from 'react'
import '../css/1.css'

//const Tabbar = ()=><div>tabber</div>
export default class App extends Component {
    state = {
        buttonText: "搜藏",
        P: <div>HCX</div>,
        v: "jack"
    }
    myRef = React.createRef()
    showElem = false
  render() {
    var obj = {
        background:'blue'
    }
    return (
      <div>
          <select id="t" onChange={
           (e)=>{   
                  console.log(document.getElementById("t").value)
                  console.log("KKKK")
                  console.log(this.state.v)
              }
          }>
            <option value = "jack">Jack</option>
            <option value = "lucy">Lucy</option>
            <option value="tom">Tom</option>
          </select>
          <div style={{display:this.showElem? 'block':'none'}}>Jack</div>
          <div >ROse</div>
      </div>
    )
  }
}
